
# Zafiro icons 
zafiro nord is a fork of the  icon pack zafiro, The color palette of most of the icons has been modified as well as new "folders" icons have been added. the new design of the folder is now most consistent whit this new icon pack
*If you find any missing application icons, please report them to me.
At the moment I only accept reports of icons of missing applications,
I am aware that icons in the other categories are still missing.*

## Donations
If you like my job and you want to help me, invite me to a cafe. Here is a link so you can donate through PayPal if you wish: [donate](https://www.paypal.me/zayronxio)

### Download and testing

download from opendesktop the latest weekly version, or from releases to have the last major update (less constant).


[<img src="https://i.imgur.com/SWAXdFr.png">](https://www.opendesktop.org/p/1891042/#files-panel) [<img src="https://i.imgur.com/gxX8nJ0.png">](https://github.com/zayronxio/Zafiro-icons/releases) 

### Installing the icons

   - Move the folder of icons to `~/.local/share/icons` (in user mode) or `/usr/share/icons` (in root mode).

   - The icon theme will be in the Settings for select


## Preview

![Preview](https://raw.githubusercontent.com/zayronxio/Zafiro-Nord-Dark/master/preview/preview.png)

